package com.solvd.mycarfactory.car;

public interface IOpen {
    void openAtAngle();
    void open();
    void activateFromClick(); // click, sensor, handle
}
