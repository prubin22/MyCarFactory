package com.solvd.mycarfactory.car;

    public class Engine implements IMotorAction {
    private String engineMaterial;
    private String engineConfiguration;
    private String engineType;

    public void engine(String engineMaterial, String engineConfiguration, String engineType) {
        this.engineMaterial = engineMaterial;
        this.engineConfiguration = engineConfiguration;
        this.engineType = engineType;
    }

    public String getEngineMaterial() {
        return engineMaterial;
    }

    public void setEngineMaterial(String engineMaterial) {
        this.engineMaterial = engineMaterial;
    }

    public String getEngineConfiguration() {
        return engineConfiguration;
    }

    public void setEngineConfiguration(String engineConfiguration) {
        this.engineConfiguration = engineConfiguration;
    }

    public String getEngineType() {
        return engineType;
    }

    public void setEngineType(String engineType) {
        this.engineType = engineType;
    }

    @Override
    public void turnOn() {
    }

    @Override
    public void showMilesPerHour() {
    }

    @Override
    public void accelerate() {
    }
}
