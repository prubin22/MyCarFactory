package com.solvd.mycarfactory.car;

    public class CarHandle implements IOpen {

    private String handleGrip;
    private String handleFeel;
    private int handleSize;

    public void carHandle(String handleGrip, String handleFeel, int handleSize){
        this.handleGrip = handleGrip;
        this.handleFeel = handleFeel;
        this.handleSize = handleSize;
    }

    public String getHandleGrip() {
        return handleGrip;
    }

    public void setHandleGrip(String handleGrip) {
        this.handleGrip = handleGrip;
    }

    public String getHandleFeel() {
        return handleFeel;
    }

    public void setHandleFeel(String handleFeel) {
        this.handleFeel = handleFeel;
    }

    public int getHandleSize() {
        return handleSize;
    }

    public void setHandleSize(int handleSize) {
         this.handleSize = handleSize;
    }

    @Override
    public void openAtAngle() {
    }

    @Override
    public void open() {
    }

    @Override
    public void activateFromClick() {
    }
}


