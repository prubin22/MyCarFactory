package com.solvd.mycarfactory.car;

import java.util.List;

public class Car {
   private static List<Integer> door;
   private static List<Integer> handle;
   private static List<Integer> bumper;
   private static List<Integer> window;
   private Trunk trunk;
   private Motor motor;
   private Engine engine;

   public static List<Integer> getDoor() {
      return door;
   }

   public static void setDoor(List<Integer> door) {
      Car.door = door;
   }

   public static List<Integer> getHandle() {
      return handle;
   }

   public static void setHandle(List<Integer> handle) {
      Car.handle = handle;
   }

   public static void add(int door) {
   } // add method for CarFactory Class

   public static void add(Object handle) {
   } // add method for CarFactory Class

   public List<Integer> getBumper() {
      return bumper;
   }

   public void setBumper(List<Integer> bumper) {
      this.bumper = bumper;
   }

   public List<Integer> getWindow() {
      return window;
   }

   public void setWindow(List<Integer> window) {
      this.window = window;
   }

   public Trunk getTrunk() {
      return trunk;
   }

   public void setTrunk(Trunk trunk) {
      this.trunk = trunk;
   }

   public Motor getMotor() {
      return motor;
   }

   public void setMotor(Motor motor) {
      this.motor = motor;
   }

   public Engine getEngine() {
      return engine;
   }

   public void setEngine(Engine engine) {
      this.engine = engine;
   }

   public static void main(String args) {
      door.add(4);
      handle.add(4);
      bumper.add(2);
      window.add(6);
   }

}



