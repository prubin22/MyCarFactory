package com.solvd.mycarfactory.employees;

    public class Management implements IManagementStyle {
    private String role;
    private String credentials;
    private int salary;
    private String name;
    private String position;

    public void management(String role, String credentials, int salary, String name, String position){
        this.role = role;
        this.credentials = credentials;
        this.salary = salary;
        this.name = name;
        this.position = position;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getCredentials() {
        return credentials;
    }

    public void setCredentials(String credentials) {
        this.credentials = credentials;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    @Override
    public void requestEmployeeRating() {
    }

    @Override
    public void addTasks() {
    }

    @Override
    public void inputProductionGoals() {
    }
}