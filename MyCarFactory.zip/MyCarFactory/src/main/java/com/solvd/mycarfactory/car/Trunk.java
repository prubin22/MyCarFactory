package com.solvd.mycarfactory.car;

    public class Trunk implements IFix {
    private String trunkLength;
    private String trunkArea;
    private String trunkMaterial;
    private String weightCapacity;

    public void trunk(String trunkLength, String trunkArea, String trunkMaterial, String weightCapacity){
        this.trunkLength = trunkLength;
        this.trunkArea = trunkArea;
        this.trunkMaterial = trunkMaterial;
        this.weightCapacity = weightCapacity;
    }

    public String getTrunkLength() {
        return trunkLength;
    }

    public void setTrunkLength(String trunkLength) {
        this.trunkLength = trunkLength;
    }

    public String getTrunkArea() {
        return trunkArea;
    }

    public void setTrunkArea(String trunkArea) {
        this.trunkArea = trunkArea;
    }

    public String getTrunkMaterial() {
        return trunkMaterial;
    }

    public void setTrunkMaterial(String trunkMaterial) {
        this.trunkMaterial = trunkMaterial;
    }

    public String getWeightCapacity() {
        return weightCapacity;
    }

    public void setWeightCapacity(String weightCapacity) {
        this.weightCapacity = weightCapacity;
    }

    @Override
    public void dismantle() {
    }

    @Override
    public void repair() {
    }

    @Override
    public void polish() {
    }
}
