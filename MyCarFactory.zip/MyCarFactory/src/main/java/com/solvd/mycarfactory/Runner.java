package com.solvd.mycarfactory;

import com.solvd.mycarfactory.employees.EmployeeLog;
import com.solvd.mycarfactory.employees.Employees;

import javax.lang.model.element.Name;
import java.io.IOException;

public class Runner {
    public static void main(String[] args) {

    Employees employee1 = new Employees();
    employee1.setName("John");
    employee1.setAge(28);

    Employees employee2 = new Employees();
    employee2.setName("Jim");
    employee2.setAge(34);

    Employees employee3 = new Employees();
    employee3.setName("Sandra");
    employee3.setAge(36);

    Employees employee4 = new Employees();
    employee4.setName("David");
    employee4.setAge(27);

    Employees employee5 = new Employees();
    employee5.setName("Harold");
    employee5.setAge(23);

    Employees employee6 = new Employees();
    employee6.setName("Kevin");
    employee6.setAge(31);

    Employees employee7 = new Employees();
    employee7.setName("Allen");
    employee7.setAge(48);

    Employees employee8 = new Employees();
    employee8.setName("Laura");
    employee8.setAge(33);

    Employees employee9 = new Employees();
    employee9.setName("Steven");
    employee9.setAge(35);

    Employees employee10 = new Employees();
    employee10.setName("Mark");
    employee10.setAge(41);

    Employees employee11 = new Employees();
    employee11.setName("Tony");
    employee11.setAge(37);

    Employees employee12 = new Employees();
    employee12.setName("George");
    employee12.setAge(29);
    }
    Employees employee1 = new Employees();
    Employees employee2 = new Employees();
    try {
        employee1.setName;
        employee1.setAge;
    } catch (IOException e) {
    }

    try {
        employee2.setName;
        employee2.setAge;
    } catch (RuntimeException e) {
    }

}
