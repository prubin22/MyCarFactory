package com.solvd.mycarfactory.carfactory;



public interface IOperations {
    void countOperationHours();
    void logOutput(); // on what gets processed
    void addMaintenance(); // for maintaining building
    void addSecurity(); //  gates or security guard
}

