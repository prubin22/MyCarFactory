package com.solvd.mycarfactory.enums;

public enum CarCount {
    SEDAN {
        public int getCount() {
            return getCount(); // of Sedans in production
        }
    },
    SUV {
        public int getCount() {
            return getCount();
        }
    },
    CRUISER {
        public int getCount() {
            return getCount();
        }
    }
}