package com.solvd.mycarfactory.car;

public interface IFix {
    void dismantle();
    void repair();
    void polish();
}
