package com.solvd.mycarfactory.enums;

public enum CountryDelivery {
    EUROPE {
        public String getValue() {
            return "Europe Orders";
        }
    },
    USA {
        public String getValue() {
            return "USA Orders";
        }
    },
    SOUTHAMERICA {
        public String getValue() {
            return "South America Orders";
        }
    },
    ASIA {
        public String getValue() {
            return "Asia orders";
        }
    }
}
