package com.solvd.mycarfactory.exceptionhandling;

public class InputMissingInOrder extends Exception {
    public InputMissingInOrder(String message) {
        super(message);
    }
}