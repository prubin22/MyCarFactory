package com.solvd.mycarfactory.carfactory;

    public class FactoryStation implements IAssort {
    private int stationSpace;
    private int employeeCount; // per station
    private String partsProcessed;

    public void factoryStation(int stationSpace, int employeeCount, String partsProcessed){
        this.stationSpace = stationSpace;
        this.employeeCount = employeeCount;
        this.partsProcessed = partsProcessed;
    }

    public int getStationSpace() {
        return stationSpace;
    }

    public void setStationSpace(int stationSpace) {
        this.stationSpace = stationSpace;
    }

    public int getEmployeeCount() {
        return employeeCount;
    }

    public void setEmployeeCount(int employeeCount) {
        this.employeeCount = employeeCount;
    }

    public String getPartsProcessed() {
        return partsProcessed;
    }

    public void setPartsProcessed(String partsProcessed) {
        this.partsProcessed = partsProcessed;
    }

    @Override
    public void assortStations() {
    }

    @Override
    public void countStations() {
    }

    @Override
    public void distributeMaterial() {
    }
}
