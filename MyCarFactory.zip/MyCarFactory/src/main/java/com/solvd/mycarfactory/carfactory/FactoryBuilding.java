package com.solvd.mycarfactory.carfactory;

    public class FactoryBuilding implements IOperations {
    private int branchNumber;
    private int factoryRating;
    private String floorType; // cement, or gloss, concrete
    private int parkingSpace;

    public void factoryBuilding(int branchNumber, int factoryRating, String floorType, int parkingSpace){
        this.branchNumber = branchNumber;
        this.factoryRating = factoryRating;
        this.floorType = floorType;
        this.parkingSpace = parkingSpace;
    }

    public int getBranchNumber() {
        return branchNumber;
    }

    public void setBranchNumber(int branchNumber) {
        this.branchNumber = branchNumber;
    }

    public int getFactoryRating() {
        return factoryRating;
    }

    public void setFactoryRating(int factoryRating) {
        this.factoryRating = factoryRating;
    }

    public String getFloorType() {
        return floorType;
    }

    public void setFloorType(String floorType) {
        this.floorType = floorType;
    }

    public int getParkingSpace() {
        return parkingSpace;
    }

    public void setParkingSpace(int parkingSpace) {
        this.parkingSpace = parkingSpace;
    }

    @Override
    public void countOperationHours() {
    }

    @Override
    public void logOutput() {
    }

    @Override
    public void addMaintenance() {
    }

    @Override
    public void addSecurity() {
    }
}