package com.solvd.mycarfactory.carfactory;

import com.solvd.mycarfactory.car.Car;

import java.util.concurrent.Callable;

public class CarFactory {
    private String output;
    private String cost;
    private int profit;

   public void carFactory(String output, String cost, int profit) {
       this.output = output;
       this.cost = cost;
       this.profit = profit;
   }

    public String getOutput() {
        return output;
    }

    public void setOutput(String output) {
        this.output = output;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public int getProfit() {
        return profit;
    }

    public void setProfit(int profit) {
        this.profit = profit;
    }

    public static void BuildCar(String args, int door, Object handle, int bumper, int window, int trunk, int motor, int engine) {
        Car.add(door);
        Car.add(handle);
        Car.add(bumper);
        Car.add(window);
        Car.add(trunk);
        Car.add(motor);
        Car.add(engine);
            }
        };

