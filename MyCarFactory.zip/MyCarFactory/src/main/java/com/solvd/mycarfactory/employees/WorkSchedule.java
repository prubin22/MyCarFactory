package com.solvd.mycarfactory.employees;

    public class WorkSchedule {
    private String scheduleType; // full-time or part-time
    private int daysOff; // per employee
    private int paidVacation; // amount of days
    private int holidayBreak; // for factory

    public void workSchedule(String scheduleType, int daysOff, int paidVacation, int holidayBreak){
        this.scheduleType = scheduleType;
        this.daysOff = daysOff;
        this.paidVacation = paidVacation;
        this.holidayBreak = holidayBreak;
    }

    public String getScheduleType() {
        return scheduleType;
    }

    public void setScheduleType(String scheduleType) {
        this.scheduleType = scheduleType;
    }

    public int getDaysOff() {
        return daysOff;
    }

    public void setDaysOff(int daysOff) {
        this.daysOff = daysOff;
    }

    public int getPaidVacation() {
        return paidVacation;
    }

    public void setPaidVacation(int paidVacation) {
        this.paidVacation = paidVacation;
    }

    public int getHolidayBreak() {
        return holidayBreak;
    }

    public void setHolidayBreak(int holidayBreak) {
        this.holidayBreak = holidayBreak;
    }

}
