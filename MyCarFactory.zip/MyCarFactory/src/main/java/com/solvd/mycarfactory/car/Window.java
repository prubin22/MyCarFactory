package com.solvd.mycarfactory.car;

public class Window {
    private String windowType;
    private String windowShape;
    private String windowCount;
    private String windowExtension;

    public void window(String windowType, String windowShape, String windowCount, String windowExtension){
        this.windowType = windowType;
        this.windowShape = windowShape;
        this.windowCount = windowCount;
        this.windowExtension = windowExtension;
    }

    public String getWindowType() {
        return windowType;
    }

    public void setWindowType(String windowType) {
        this.windowType = windowType;
    }

    public String getWindowShape() {
        return windowShape;
    }

    public void setWindowShape(String windowShape) {
        this.windowShape = windowShape;
    }

    public String getWindowCount() {
        return windowCount;
    }

    public void setWindowCount(String windowCount) {
        this.windowCount = windowCount;
    }

    public String getWindowExtension() {
        return windowExtension;
    }

    public void setWindowExtension(String windowExtension) {
        this.windowExtension = windowExtension;
    }
}
