package com.solvd.mycarfactory.employees;

    public class Employees implements IProductivity {
        public Object setName;
        public Object setAge;
        private String name;
    private int count;
    private String experience;
    private String jobDescription;
    private int age;

    public void employees(String name, int count, String experience, String jobDescription, int age) {
        this.name = name;
        this.count = count;
        this.experience = experience;
        this.jobDescription = jobDescription;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public void logDailyOutput() {
    }

    @Override
    public void countTotalOutput() {
    }

    @Override
    public void inputTimeLog() {
    }

    @Override
    public void extractTimeSpent() {
    }
}