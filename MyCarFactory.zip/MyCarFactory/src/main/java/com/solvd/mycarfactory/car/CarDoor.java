package com.solvd.mycarfactory.car;

public class CarDoor implements IOpen {
    private int doorSize;
    private String doorType;
    private String doorColor;

    public void carDoor(int doorSize, String doorType, String doorColor) {
        this.doorSize = doorSize;
        this.doorType = doorType;
        this.doorColor = doorColor;
    }

    public int getDoorSize() {
        return doorSize;
    }

    public void setDoorSize(int doorSize) {
        this.doorSize = doorSize;
    }

    public String getDoorType() {
        return doorType;
    }

    public void setDoorType(String doorType) {
        this.doorType = doorType;
    }

    public String getDoorColor() {
        return doorColor;
    }

    public void setDoorColor(String doorColor) {
        this.doorColor = doorColor;
    }

    @Override
    public void openAtAngle() {
    }

    @Override
    public void open() {
    }

    @Override
    public void activateFromClick() {
    }
}
