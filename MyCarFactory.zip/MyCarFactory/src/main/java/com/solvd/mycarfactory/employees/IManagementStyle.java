package com.solvd.mycarfactory.employees;



public interface IManagementStyle {
    void requestEmployeeRating();
    void addTasks();
    void inputProductionGoals();
}