package com.solvd.mycarfactory.carfactory;



public interface IAssort {
     void assortStations();
     void countStations();
     void distributeMaterial();
}
