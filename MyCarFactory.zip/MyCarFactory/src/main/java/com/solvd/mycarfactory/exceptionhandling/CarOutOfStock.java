package com.solvd.mycarfactory.exceptionhandling;

public class CarOutOfStock extends Exception {
    public CarOutOfStock(String message) {
        super(message);
    }
}
