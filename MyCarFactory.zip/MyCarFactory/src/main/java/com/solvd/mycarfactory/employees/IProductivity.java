package com.solvd.mycarfactory.employees;

// @FunctionalInterface

public interface IProductivity {
    void logDailyOutput();
    void countTotalOutput();
    void inputTimeLog(); // input work time into log
    void extractTimeSpent(); // scan input
}
