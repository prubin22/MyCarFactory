package com.solvd.mycarfactory.exceptionhandling;

public class LocationNotInRange extends Exception {
    public LocationNotInRange(String message) {
        super(message);
    }
}
