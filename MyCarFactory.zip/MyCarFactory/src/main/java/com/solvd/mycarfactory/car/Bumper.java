package com.solvd.mycarfactory.car;

    public class Bumper implements IFix {
    private int bumperSize;
    private int bumperMaterial;
    private String bumperStrength;
    private String bumperShape;

    public void bumper(int bumperSize, int bumperMaterial, String bumperStrength, String bumperShape){
        this.bumperSize = bumperSize;
        this.bumperMaterial = bumperMaterial;
        this.bumperStrength = bumperStrength;
        this.bumperShape = bumperShape;
    }

    public int getBumperSize() {
        return bumperSize;
    }

    public void setBumperSize(int bumperSize) {
        this.bumperSize = bumperSize;
    }

    public int getBumperMaterial() {
        return bumperMaterial;
    }

    public void setBumperMaterial(int bumperMaterial) {
        this.bumperMaterial = bumperMaterial;
    }

    public String getBumperStrength() {
        return bumperStrength;
    }

    public void setBumperStrength(String bumperStrength) {
        this.bumperStrength = bumperStrength;
    }

    public String getBumperShape() {
        return bumperShape;
    }

    public void setBumperShape(String bumperShape) {
        this.bumperShape = bumperShape;
    }

    @Override
    public void dismantle() {
    }

    @Override
    public void repair() {
    }

    @Override
    public void polish() {
    }
}


