package com.solvd.mycarfactory.car;

    public class Motor implements IMotorAction {
    private String motorType;
    private int amplitude;
    private String motorSize;

    public void motor(String motorType, int amplitude, String motorSize) {
        this.motorType = motorType;
        this.amplitude = amplitude;
        this.motorSize = motorSize;
    }

    public String getMotorType() {
        return motorType;
    }

    public void setMotorType(String motorType) {
        this.motorType = motorType;
    }

    public int getAmplitude() {
        return amplitude;
    }

    public void setAmplitude(int amplitude) {
        this.amplitude = amplitude;
    }

    public String getMotorSize() {
        return motorSize;
    }

    public void setMotorSize(String motorSize) {
        this.motorSize = motorSize;
    }

    @Override
    public void turnOn() {
    }

    @Override
    public void showMilesPerHour() {
    }

    @Override
    public void accelerate() {
    }
}



