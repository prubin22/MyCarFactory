package com.solvd.mycarfactory.exceptionhandling;

public class ShipmentIsDelayed extends Exception{
    public ShipmentIsDelayed(String message) {
        super(message);
    }
}
