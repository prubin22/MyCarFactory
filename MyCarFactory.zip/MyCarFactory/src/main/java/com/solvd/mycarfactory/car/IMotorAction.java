package com.solvd.mycarfactory.car;

public interface IMotorAction {
    void turnOn(); //revolutions per min
    void showMilesPerHour();
    void accelerate();
}
